This folder contains the Frontend code for the Online Auction System Website made using Mern stack

The frontend is deployed on render.com 

See it live at : https://bidbotauctionsystem.onrender.com
